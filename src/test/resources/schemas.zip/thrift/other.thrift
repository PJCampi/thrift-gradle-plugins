namespace * test

struct TestStruct2 {
	1:required i32 num = 0,
}

